arr = range(1,11)
print(list(arr))
print(arr)