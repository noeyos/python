a = 0
b = 0.1


print(a+b)