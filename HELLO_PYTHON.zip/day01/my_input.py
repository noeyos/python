a = input("좋아하는 과일을 고르세요")
print(a)