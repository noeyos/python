# 1에서 10까지의 합을 구하시오

arr = range(1, 11)
res = 0
for i in arr:
    res += i
print(res)