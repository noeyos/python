a = True

if a :
    print("참")
    print("하하")
