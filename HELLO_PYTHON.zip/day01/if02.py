a = False

if a :
    print("참")
else :
    print("거짓")
print("babo")