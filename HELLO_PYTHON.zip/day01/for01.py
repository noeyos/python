arr = range(1,6)

for i in arr:
    print(i)

