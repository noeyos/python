arr = ["홍길동", "홍", "길", "동"]

print(arr[0])

arr.append("윤석열")
arr.insert(len(arr), "기시다")

print(arr)

print(len(arr))