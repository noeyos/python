a = 1
b = "3"
print(str(a)+b)
print(a+int(b))

