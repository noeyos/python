print("hello") #System.out.println
print("hello")

print("hello", end="") #System.out.print
print("hello", end="")
