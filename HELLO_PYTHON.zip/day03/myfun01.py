def add(a, b):
    return a+b
def minus(a, b):
    return a-b
def multiply(a, b):
    return a*b
def divide(a, b):
    return a/b

sum = add(4,2)
min = minus(4,2)
mul = multiply(4, 2)
div = divide(4,2)
print("sum", sum)
print("min", min)
print("mul", mul)
print("div", div)

