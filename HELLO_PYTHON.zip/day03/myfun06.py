def add_min_mul_div(a,b):
    return a+b,a-b,a*b,a/b

# 튜플
sum = add_min_mul_div(4, 2)



