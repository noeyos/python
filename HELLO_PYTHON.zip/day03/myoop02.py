from day03.myoop01 import Animal
a = Animal()
print(a.flag_sound)
a.bbeonguri()
print(a.flag_sound)

